package com.irfan.findertest

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.security.SecureRandom

/**
 * Step 1 of the finder network: one phone sends a BLE beacon ("Lost mode"),
 * another phone scans for it ("Finder mode"). Works with no SIM, data or Wi-Fi.
 */
class MainActivity : Activity() {

    companion object {
        const val COMPANY_ID = 0xFFFF                 // Bluetooth "test" company ID, OK for prototypes
        val MAGIC = byteArrayOf(0x46, 0x4E)           // "FN" = Finder Network marker
    }

    private lateinit var statusText: TextView
    private lateinit var listText: TextView
    private lateinit var myId: ByteArray
    private val handler = Handler(Looper.getMainLooper())
    private val seen = LinkedHashMap<String, Pair<Int, Long>>() // id -> (rssi, lastSeenMs)
    private var advertising = false
    private var scanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        myId = loadOrCreateId()
        buildUi()
        askPermissions()
    }

    // ---------- ID ----------
    private fun loadOrCreateId(): ByteArray {
        val prefs = getSharedPreferences("finder", MODE_PRIVATE)
        prefs.getString("id", null)?.let { return hexToBytes(it) }
        val id = ByteArray(6).also { SecureRandom().nextBytes(it) }
        prefs.edit().putString("id", toHex(id)).apply()
        return id
    }

    // ---------- UI ----------
    private fun buildUi() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val title = TextView(this).apply { text = "Finder Test"; textSize = 24f }
        val idText = TextView(this).apply { text = "My ID: ${toHex(myId)}"; textSize = 16f }
        statusText = TextView(this).apply {
            text = "Status: idle"; textSize = 16f; setPadding(0, pad / 2, 0, pad / 2)
        }
        val btnLost = Button(this).apply { text = "Lost mode (send beacon)"; setOnClickListener { startBeacon() } }
        val btnFind = Button(this).apply { text = "Finder mode (scan)"; setOnClickListener { startScan() } }
        val btnStop = Button(this).apply { text = "Stop all"; setOnClickListener { stopAll() } }
        listText = TextView(this).apply { textSize = 15f; setPadding(0, pad, 0, 0) }
        val scroll = ScrollView(this).apply { addView(listText) }

        listOf(title, idText, statusText, btnLost, btnFind, btnStop).forEach { root.addView(it) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun status(s: String) { statusText.text = s }

    // ---------- Permissions ----------
    private fun neededPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) else arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

    private fun hasPermissions() = neededPermissions().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun askPermissions() {
        if (!hasPermissions()) ActivityCompat.requestPermissions(this, neededPermissions(), 1)
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    @SuppressLint("MissingPermission")
    private fun readyAdapter(): BluetoothAdapter? {
        if (!hasPermissions()) { status("Please allow Bluetooth + Location permissions"); askPermissions(); return null }
        val a = adapter() ?: run { status("This phone has no Bluetooth"); return null }
        if (!a.isEnabled) { status("Turn ON Bluetooth and Location first"); return null }
        return a
    }

    // ---------- Lost mode: send beacon ----------
    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            advertising = true; status("Lost mode ON - beacon sending")
        }
        override fun onStartFailure(errorCode: Int) {
            advertising = false; status("Beacon failed (error $errorCode)")
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBeacon() {
        val a = readyAdapter() ?: return
        if (advertising) return
        val advertiser = a.bluetoothLeAdvertiser ?: run {
            status("This phone can't send BLE beacons. Use it as the finder instead."); return
        }
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(false)
            .build()
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addManufacturerData(COMPANY_ID, MAGIC + myId)
            .build()
        advertiser.startAdvertising(settings, data, advertiseCallback)
    }

    // ---------- Finder mode: scan ----------
    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val bytes = result.scanRecord?.getManufacturerSpecificData(COMPANY_ID) ?: return
            if (bytes.size < 8 || bytes[0] != MAGIC[0] || bytes[1] != MAGIC[1]) return
            val id = toHex(bytes.copyOfRange(2, 8))
            seen[id] = Pair(result.rssi, System.currentTimeMillis())
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false; status("Scan failed (error $errorCode)")
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        val a = readyAdapter() ?: return
        if (scanning) return
        val scanner = a.bluetoothLeScanner ?: run { status("Scanner not available"); return }
        val filter = ScanFilter.Builder()
            .setManufacturerData(
                COMPANY_ID,
                MAGIC + ByteArray(6),
                byteArrayOf(-1, -1, 0, 0, 0, 0, 0, 0) // only match the "FN" marker
            ).build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        scanner.startScan(listOf(filter), settings, scanCallback)
        scanning = true
        status("Finder mode ON - scanning...")
        handler.post(refresher)
    }

    private val refresher = object : Runnable {
        override fun run() {
            if (!scanning) return
            val now = System.currentTimeMillis()
            val sb = StringBuilder("Phones found nearby:\n\n")
            if (seen.isEmpty()) sb.append("None yet. Put the other phone in Lost mode.")
            for ((id, v) in seen) {
                val (rssi, t) = v
                val ago = (now - t) / 1000
                val dist = when {
                    rssi > -60 -> "very close"
                    rssi > -75 -> "near"
                    rssi > -90 -> "far"
                    else -> "very far"
                }
                sb.append("ID $id\nSignal $rssi dBm ($dist) - seen ${ago}s ago\n\n")
            }
            listText.text = sb.toString()
            handler.postDelayed(this, 1000)
        }
    }

    // ---------- Stop ----------
    @SuppressLint("MissingPermission")
    private fun stopAll() {
        val a = adapter()
        try {
            if (advertising) a?.bluetoothLeAdvertiser?.stopAdvertising(advertiseCallback)
            if (scanning) a?.bluetoothLeScanner?.stopScan(scanCallback)
        } catch (_: Exception) { }
        advertising = false
        scanning = false
        status("Status: idle")
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    // ---------- Helpers ----------
    private fun toHex(b: ByteArray) = b.joinToString("") { "%02X".format(it) }
    private fun hexToBytes(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}
